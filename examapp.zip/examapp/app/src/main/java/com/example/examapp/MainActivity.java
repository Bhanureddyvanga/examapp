package com.example.examapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    Spinner spinnercourse;
    TextView feetv, hourstv;
    Button addbutton;
    CheckBox accomcb, medicalcb;

    //to show in spinner
    String coursenames[] = {"Java", "Swift", "iOS", "Android", "Database"};
    String coursefee[] = {"1300", "1500", "1350", "1400", "1000"};
    String coursehours[] = {"6", "5", "5", "7", "4"};

    //when nothing is selected
    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }

    //to
    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int i, long l)
    {
        feetv.setText(coursefee[i]);
        hourstv.setText(coursehours[i]);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        spinnercourse = findViewById(R.id.spinnercourse);
        feetv = findViewById(R.id.feetv);
        hourstv = findViewById(R.id.hourstv);

        spinnercourse.setOnItemSelectedListener(this);


        ArrayAdapter aa = new ArrayAdapter(this, android.R.layout.simple_spinner_item, coursenames);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnercourse.setAdapter(aa);
    }

    //to show o/p in fee and hours view
    @Override
    public void onClick(View v) {
        int i = spinnercourse.getSelectedItemPosition();
        TextView feeTotal;
        feetv.setText(coursefee[i]);
        hourstv.setText(coursehours[i]);
    }
}
