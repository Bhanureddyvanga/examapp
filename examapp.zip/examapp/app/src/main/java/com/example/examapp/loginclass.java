package com.example.examapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class loginclass extends AppCompatActivity implements View.OnClickListener {
    EditText user, pass;
    Button login;
    static EditText name;
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_app);
        user = findViewById(R.id.usertext);
        pass = findViewById(R.id.passwordtext);
        name = findViewById(R.id.nametext);
        login = findViewById(R.id.loginbn);
        login.setOnClickListener(this);
    }
    @Override
    public void onClick(View view){

        if (user.getText().toString().equalsIgnoreCase( "student1") && pass.getText().toString().equals("123456"))
        {
            Intent intent = new Intent( this, MainActivity.class );
            startActivity(intent);

        }
        else
            Toast.makeText(getApplicationContext(), "Invalid username or password", Toast.LENGTH_LONG).show();
    }

}
